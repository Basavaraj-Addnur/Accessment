package com.example.companies.controller;

import com.example.companies.model.Company;
import com.example.companies.repository.CompanyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.*;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/companies")
@CrossOrigin(origins = "*") // allow all origins for simplicity; restrict in production
public class CompanyController {

    @Autowired
    private CompanyRepository repo;

    /**
     * GET /api/companies
     * Query params:
     *  - page (0-based)
     *  - size
     *  - sort (example: name,asc or employees,desc)
     *  - name (string contained)
     *  - location
     *  - industry
     */
    @GetMapping
    public Page<Company> list(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "name,asc") String sort,
            @RequestParam(defaultValue = "") String name,
            @RequestParam(defaultValue = "") String location,
            @RequestParam(defaultValue = "") String industry
    ) {
        String[] sortParts = sort.split(",");
        Sort s = Sort.by(sortParts[0]);
        if (sortParts.length > 1 && sortParts[1].equalsIgnoreCase("desc")) s = s.descending(); else s = s.ascending();

        Pageable pageable = PageRequest.of(page, size, s);
        return repo.findByNameContainingIgnoreCaseAndLocationContainingIgnoreCaseAndIndustryContainingIgnoreCase(
                name, location, industry, pageable);
    }

    @GetMapping("/locations")
    public List<String> locations() {
        return repo.findAll()
                .stream()
                .map(Company::getLocation)
                .distinct()
                .sorted()
                .toList();
    }

    @GetMapping("/industries")
    public List<String> industries() {
        return repo.findAll()
                .stream()
                .map(Company::getIndustry)
                .distinct()
                .sorted()
                .toList();
    }
}
