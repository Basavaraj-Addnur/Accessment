package com.example.companies.repository;

import com.example.companies.model.Company;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CompanyRepository extends JpaRepository<Company, Long> {
    // a simple name/location/industry filter via query method
    Page<Company> findByNameContainingIgnoreCaseAndLocationContainingIgnoreCaseAndIndustryContainingIgnoreCase(
        String name, String location, String industry, Pageable pageable);
}
