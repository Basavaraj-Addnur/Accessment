package com.example.companies.util;

import com.example.companies.model.Company;
import com.example.companies.repository.CompanyRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataLoader implements CommandLineRunner {

    private final CompanyRepository repo;

    public DataLoader(CompanyRepository repo) { this.repo = repo; }

    @Override
    public void run(String... args) throws Exception {
        if (repo.count() > 0) return;

        repo.save(new Company("AlphaTech", "Bengaluru", "Software", 120, "https://alphatech.example"));
        repo.save(new Company("BetaFoods", "Mumbai", "Food & Beverage", 80, "https://betafoods.example"));
        repo.save(new Company("GammaFinance", "Mumbai", "Finance", 350, "https://gamma.example"));
        repo.save(new Company("DeltaHealth", "Delhi", "Healthcare", 45, "https://delta.example"));
        repo.save(new Company("EpsilonAI", "Bengaluru", "AI", 200, "https://epsilon.example"));
        repo.save(new Company("ZetaLogistics", "Chennai", "Logistics", 60, "https://zeta.example"));
        repo.save(new Company("EtaEnergy", "Hyderabad", "Energy", 220, "https://eta.example"));
        repo.save(new Company("ThetaDesign", "Pune", "Design", 25, "https://theta.example"));
        // add a few more for pagination demo
        for(int i=1;i<=40;i++){
            repo.save(new Company("TestCo " + i, i%2==0 ? "Bengaluru" : "Mumbai", i%3==0 ? "Software" : "Other", 5 + i, "https://test"+i+".example"));
        }
    }
}
