import {
  Table, TableBody, TableCell, TableContainer, TableHead,
  TableRow, Paper, TableSortLabel, Pagination
} from "@mui/material";

export default function CompanyTable({ companies, sort, setSort }) {
  return (
    <Paper sx={{ borderRadius: 3, overflow: "hidden" }}>
      <TableContainer>
        <Table>
          <TableHead sx={{ background: "#111827" }}>
            <TableRow>
              {["Name", "Industry", "Location"].map((column) => (
                <TableCell key={column} sx={{ color: "white" }}>
                  <TableSortLabel
                    active={sort.field === column.toLowerCase()}
                    direction={sort.direction}
                    onClick={() =>
                      setSort({
                        field: column.toLowerCase(),
                        direction: sort.direction === "asc" ? "desc" : "asc",
                      })
                    }
                  >
                    {column}
                  </TableSortLabel>
                </TableCell>
              ))}
            </TableRow>
          </TableHead>

          <TableBody>
            {companies.map((c) => (
              <TableRow hover key={c.id}>
                <TableCell>{c.name}</TableCell>
                <TableCell>{c.industry}</TableCell>
                <TableCell>{c.location}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      <Pagination count={5} sx={{ p: 2, display: "flex", justifyContent: "center" }} />
    </Paper>
  );
}
