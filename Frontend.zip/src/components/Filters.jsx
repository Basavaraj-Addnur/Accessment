import { Box, TextField, MenuItem, Paper } from "@mui/material";

export default function Filters({ filters, setFilters }) {
  return (
    <Paper sx={{ padding: 2, display: "flex", gap: 2, mb: 2 }}>
      <TextField
        label="Search by name"
        variant="outlined"
        fullWidth
        value={filters.search}
        onChange={(e) => setFilters({ ...filters, search: e.target.value })}
      />
      <TextField
        label="Industry"
        select
        sx={{ width: 200 }}
        value={filters.industry}
        onChange={(e) => setFilters({ ...filters, industry: e.target.value })}
      >
        <MenuItem value="">All</MenuItem>
        <MenuItem value="IT">IT</MenuItem>
        <MenuItem value="Finance">Finance</MenuItem>
      </TextField>
    </Paper>
  );
}
