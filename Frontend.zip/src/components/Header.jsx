import { AppBar, Toolbar, Typography, Box } from "@mui/material";

export default function Header() {
  return (
    <AppBar
      position="fixed"
      sx={{
        zIndex: (theme) => theme.zIndex.drawer + 1,
        background: "white",
        color: "black",
        boxShadow: "0px 2px 8px rgba(0,0,0,0.1)"
      }}
    >
      <Toolbar>
        <Typography variant="h6" sx={{ flexGrow: 1 }}>
          Company Directory
        </Typography>
      </Toolbar>
    </AppBar>
  );
}
