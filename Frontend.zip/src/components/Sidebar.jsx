import { Drawer, List, ListItemButton, ListItemText, Toolbar, Typography, Box } from "@mui/material";

export default function Sidebar() {
  return (
    <Drawer
      variant="permanent"
      sx={{
        width: 240,
        flexShrink: 0,
        [`& .MuiDrawer-paper`]: {
          width: 240,
          boxSizing: "border-box",
          background: "#111827",
          color: "white",
        },
      }}
    >
      <Toolbar>
        <Typography variant="h6" sx={{ fontWeight: 700 }}>
          Companies
        </Typography>
      </Toolbar>
      <Box sx={{ overflow: "auto" }}>
        <List>
          <ListItemButton>
            <ListItemText primary="Dashboard" />
          </ListItemButton>
        </List>
      </Box>
    </Drawer>
  );
}
