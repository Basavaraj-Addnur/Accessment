import { Box, Toolbar } from "@mui/material";
import Filters from "../components/Filters";
import CompanyTable from "../components/CompanyTable";
import { useEffect, useState } from "react";
import { getAllCompanies } from "../api";

export default function Dashboard() {
  const [companies, setCompanies] = useState([]);
  const [filters, setFilters] = useState({ search: "", industry: "" });
  const [sort, setSort] = useState({ field: "name", direction: "asc" });

  useEffect(() => {
    getAllCompanies().then((res) => setCompanies(res));
  }, []);

  return (
    <Box sx={{ flexGrow: 1, p: 3 }}>
      <Toolbar />
      <Filters filters={filters} setFilters={setFilters} />
      <CompanyTable
        companies={companies}
        sort={sort}
        setSort={setSort}
      />
    </Box>
  );
}
